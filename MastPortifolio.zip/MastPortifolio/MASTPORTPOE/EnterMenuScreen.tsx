import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, StyleSheet } from 'react-native';

interface MenuItem {
  name: string;
  description: string;
  course: string;
  price: string;
}

interface EnterMenuScreenProps {
  navigation: any;
  route: { params: { menuItems: MenuItem[] } };
}

const EnterMenuScreen: React.FC<EnterMenuScreenProps> = ({ navigation, route }) => {
  const { menuItems = [] } = route.params || {};
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [course, setCourse] = useState<string>('');
  const [price, setPrice] = useState<string>('');

  const handleAddItem = () => {
    const newItem: MenuItem = { name, description, course, price };
    navigation.navigate('Home', { menuItems: [...menuItems, newItem] });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>BIG On Taste</Text>
      <Text style={styles.subTitle}>Enter Menu</Text>

      <TextInput
        placeholder="Dish Name"
        value={name}
        onChangeText={setName}
        style={styles.input}
      />
      <TextInput
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
        style={styles.input}
      />
      <TextInput
        placeholder="Course (Starter, Main, Dessert)"
        value={course}
        onChangeText={setCourse}
        style={styles.input}
      />
      <TextInput
        placeholder="Price"
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
        style={styles.input}
      />

      <View style={styles.bottomNav}>
        <TouchableOpacity onPress={handleAddItem}>
          <Text style={styles.bottomNavText}>✔</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setName('')}>
          <Text style={styles.bottomNavText}>❌</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.bottomNav}>
        <TouchableOpacity onPress={() => navigation.navigate('Home', { menuItems })}>
          <Text style={styles.bottomNavText}>🏠</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Enter Menu', { menuItems })}>
          <Text style={styles.bottomNavText}>⬇</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#CACFD6',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 48,
    fontWeight: '400',
    color: '#000',
    textAlign: 'center',
    marginBottom: 20,
  },
  subTitle: {
    fontSize: 30,
    color: '#000',
    textAlign: 'center',
    marginBottom: 10,
  },
  input: {
    width: '90%',
    height: 40,
    borderColor: '#333',
    borderWidth: 1,
    marginBottom: 10,
    padding: 8,
    backgroundColor: '#fff',
    borderRadius: 4,
  },
  bottomNav: {
    flexDirection: 'row',
    marginTop: 20,
  },
  bottomNavText: {
    fontSize: 30,
    margin: 10,
  },
});

export default EnterMenuScreen;