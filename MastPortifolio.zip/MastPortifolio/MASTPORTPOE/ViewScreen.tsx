import React, { useState } from 'React';
import { View, TextInput, FlatList, TouchableOpacity, Text, StyleSheet } from '';

interface MenuItem {
  name: string;
  description: string;
  course: string;
  price: string;
}

interface ViewScreenProps {
  navigation: any;
  route: { params: { menuItems: MenuItem[] } };
}

const ViewScreen: React.FC<ViewScreenProps> = ({ navigation, route }) => {
  const { menuItems = [] } = route.params || {};
  const [selectedCourse, setSelectedCourse] = useState<string>('');
  const [bookingDate, setBookingDate] = useState<string>('');
  const [client, setClient] = useState<string>('');

  const filteredItems = selectedCourse
    ? menuItems.filter((item) => item.course === selectedCourse)
    : menuItems;

  const handleSavePreparedMenu = () => {
    alert('Prepared menu saved for client!');
    navigation.navigate('Home', { menuItems });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>Chef's View</Text>
      <TextInput
        placeholder="Enter Booking Date"
        value={bookingDate}
        onChangeText={setBookingDate}
        style={styles.input}
      />
      <TextInput
        placeholder="Choose Client"
        value={client}
        onChangeText={setClient}
        style={styles.input}
      />

      <View style={styles.filterButtons}>
        {['Starter', 'Main', 'Dessert'].map((course) => (
          <TouchableOpacity
            key={course}
            onPress={() => setSelectedCourse(course)}
            style={styles.filterButton}
          >
            <Text style={styles.filterButtonText}>{course}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity onPress={() => setSelectedCourse('')} style={styles.filterButton}>
          <Text style={styles.filterButtonText}>Show All</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredItems}
        keyExtractor={(item) => item.name}
        renderItem={({ item }) => (
          <View style={styles.menuItem}>
            <Text>{item.name} - {item.course}</Text>
            <Text>Price: R{item.price}</Text>
            <Text>Description: {item.description}</Text>
          </View>
        )}
      />

      <TouchableOpacity onPress={handleSavePreparedMenu} style={styles.button}>
        <Text>Save Prepared Menu</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#CACFD6',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 48,
    fontWeight: '400',
    color: '#000',
    textAlign: 'center',
    marginBottom: 20,
  },
  filterButtons: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  filterButton: {
    backgroundColor: '#94B3A1',
    padding: 10,
    margin: 5,
    borderRadius: 5,
  },
  filterButtonText: {
    color: '#fff',
  },
  input: {
    width: '90%',
    height: 40,
    borderColor: '#333',
    borderWidth: 1,
    marginBottom: 10,
    padding: 8,
    backgroundColor: '#fff',
    borderRadius: 4,
  },
  button: {
    backgroundColor: '#94B3A1',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  menuItem: {
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
  },
});

export default ViewScreen;
