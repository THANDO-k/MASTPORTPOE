import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

interface MenuItem {
  name: string;
  description: string;
  course: string;
  price: string;
}

interface HomeScreenProps {
  navigation: any;
  route: { params: { menuItems: MenuItem[] } };
}

const HomeScreen: React.FC<HomeScreenProps> = ({ navigation, route }) => {
  const { menuItems = [] } = route.params || {};
  const [selectedCourse, setSelectedCourse] = useState<string>('');

  const filteredItems = selectedCourse
    ? menuItems.filter((item) => item.course === selectedCourse)
    : menuItems;

  const totalPrice = filteredItems.reduce(
    (total, item) => total + parseFloat(item.price || '0'),
    0
  );
  const avgPrice = filteredItems.length > 0 ? (totalPrice / filteredItems.length).toFixed(2) : '0.00';

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>BIG On Taste</Text>
      <Text style={styles.subTitle}>Meals of the Day</Text>

      <View style={styles.filterButtons}>
        {['Starter', 'Main', 'Dessert'].map((course) => (
          <TouchableOpacity key={course} onPress={() => setSelectedCourse(course)} style={styles.filterButton}>
            <Text style={styles.filterButtonText}>{course}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity onPress={() => setSelectedCourse('')} style={styles.filterButton}>
          <Text style={styles.filterButtonText}>Show All</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredItems}
        keyExtractor={(item) => item.name}
        renderItem={({ item }) => (
          <View style={styles.menuItem}>
            <Text>{item.name} - {item.course}</Text>
            <Text>Price: R{item.price}</Text>
            <Text>Description: {item.description}</Text>
          </View>
        )}
      />

      <Text style={styles.totText}>Total items: {filteredItems.length}</Text>
      <Text style={styles.totText}>Average Price: R{avgPrice}</Text>

      <View style={styles.bottomNav}>
        <TouchableOpacity onPress={() => navigation.navigate('Home', { menuItems })}>
          <Text style={styles.bottomNavText}>🏠</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Enter Menu', { menuItems })}>
          <Text style={styles.bottomNavText}>⬇</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#CACFD6',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 48,
    fontWeight: '400',
    color: '#000',
    textAlign: 'center',
    marginBottom: 20,
  },
  subTitle: {
    fontSize: 30,
    color: '#000',
    textAlign: 'center',
    marginBottom: 10,
  },
  filterButtons: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  filterButton: {
    backgroundColor: '#94B3A1',
    padding: 10,
    margin: 5,
    borderRadius: 5,
  },
  filterButtonText: {
    color: '#fff',
  },
  totText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
  },
  bottomNav: {
    flexDirection: 'row',
    marginTop: 20,
  },
  bottomNavText: {
    fontSize: 30,
    margin: 10,
  },
  menuItem: {
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
  },
});

export default HomeScreen;
